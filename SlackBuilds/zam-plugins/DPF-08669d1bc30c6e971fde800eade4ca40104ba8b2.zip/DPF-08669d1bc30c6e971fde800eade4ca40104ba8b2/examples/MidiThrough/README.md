# MidiThrough example

This example will show how to use MIDI output in DPF based plugins.<br/>

It simply calls writeMidiEvent() in its process function for every event it receives.

