# Parameters example

This example will show how parameters work in DPF.<br/>
The plugin will not do any audio processing.<br/>

In this example the UI will display a 3x3 grid of colors which can be changed or automated by the host.<br/>
There are 2 colors: blue and orange. Blue means off, orange means on.<br/>
When a grid block is clicked its color will change and the host will receive a parameter change.<br/>
When the host changes a plugin parameter the UI will update accordingly.<br/>
