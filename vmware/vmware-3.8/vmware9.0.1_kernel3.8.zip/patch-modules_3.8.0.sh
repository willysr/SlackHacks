#! /bin/bash
# VMWare Workstation/Player _host kernel modules_ patcher by Willy Sudiarto Raharjo
# Updated for VMware 9.0.1 / VMplayer 5.0.1 on kernel 3.8
# Use at your own risk.
# Credit goes to Tim who supplied the patch
# http://rglinuxtech.com/2013/01/18/3-8-rc4-vmware-problem-but-old-nvidia-still-ok/

fpatch=vmware-3.8.patch
vmreqver=9.0.1
plreqver=5.0.1


error()
{
	echo "$*. Exiting"
	exit
}

curdir=`pwd`
bdate=`date "+%F-%H:%M:%S"` || error "date utility didn't quite work. Hm"
vmver=`vmware-installer -l 2>/dev/null | awk '/vmware-/{print $1substr($2,1,5)}'`
vmver="${vmver#vmware-}"
basedir=/usr/lib/vmware/modules/source
ptoken="$basedir/.patched"
bkupdir="$basedir-$vmver-$bdate-backup"

unset product
[ -z "$vmver" ] && error "VMWare is not installed (properly) on this PC"
[ "$vmver" == "workstation$vmreqver" ] && product="VMWare WorkStation"
[ "$vmver" == "player$plreqver" ] && product="VMWare Player"
[ -z "$product" ] && error "Sorry, this script is only for VMWare WorkStation $vmreqver or VMWare Player $plreqver"

[ "`id -u`" != "0" ] && error "You must be root to run this script"
[ -f "$ptoken" ] && error "$ptoken found. You have already patched your sources"
[ ! -d "$basedir" ] && error "Source '$basedir' directory not found, reinstall $product"
[ ! -f "$fpatch" ] && error "'$fpatch' not found. Please, copy it to the current '$curdir' directory"

tmpdir=`mktemp -d` || exit 1
cp -an "$basedir" "$bkupdir" || exit 2

cd "$tmpdir" || exit 3
find "$basedir" -name "*.tar" -exec tar xf '{}' \; || exit 4

patch -p0 < "$curdir/$fpatch" || exit 5
tar cf vmci.tar vmci-only || exit 6

cp -a *.tar "$basedir" || exit 20
rm -rf "$tmpdir" || exit 21
touch "$ptoken" || exit 22
cd "$curdir" || exit 23

vmware-modconfig --console --install-all

echo -e "\n"
echo "All done, you can now run $product."
echo "Modules sources backup can be found in the '$bkupdir' directory"
